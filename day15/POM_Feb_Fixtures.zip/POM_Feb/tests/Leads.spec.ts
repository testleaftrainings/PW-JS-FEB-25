import {test} from '../utility/myFixture'
import { LeadsPage } from "../pages/LeadsPage";
import fs from 'fs'
import { URLConstants } from "../data/urlconstants";
let loginData:any[]

test.beforeEach(``,async()=>{
   loginData=JSON.parse(fs.readFileSync("data/login.json",'utf-8'))
})

test(`Leads Module`,async({lp})=>{
     await lp.navigate(URLConstants.baseUrl)  
     await lp.enterCredentials(loginData[0].Username,loginData[0].Password)
     await lp.doLogin()
     await lp.clickCRM()
     await lp.clickLeads()
     await lp.clickCreateLead()

})