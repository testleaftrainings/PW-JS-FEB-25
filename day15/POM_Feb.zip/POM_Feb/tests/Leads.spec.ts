import test from "@playwright/test";
import { LeadsPage } from "../pages/LeadsPage";
import fs from 'fs'
let loginData:any[]

test.beforeEach(`LoginData`,async()=>{
    loginData=JSON.parse(fs.readFileSync("data/login.json",'utf-8'))
})

test(`Leads Module ${loginData[0].TCaseId}`,async({context,page})=>{
    const leadsPage=new LeadsPage(context,page)
    await leadsPage.navigate()
    await leadsPage.enterCredentials(loginData[0].Username,loginData[0].Password)
    await leadsPage.doLogin()
    await leadsPage.clickCRM()
    await leadsPage.clickLeads()
    await leadsPage.clickCreateLead()
})