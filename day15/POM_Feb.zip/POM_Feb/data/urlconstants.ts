export enum URLConstants{
    baseUrl="http://leaftaps.com/opentaps/control/main",
    homePageUrl="http://leaftaps.com/opentaps/control/login"
}