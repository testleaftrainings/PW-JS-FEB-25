import {BrowserContext, Page} from '@playwright/test'
import { URLConstants } from '../data/urlconstants'

export class LoginPage{
    page:Page 
    context:BrowserContext

   constructor(context:BrowserContext,page:Page){
    this.page=page
    this.context=context
   }

   public selectors={
     usernameField:"#username",
     pwdField:"#password",
     loginButton:"//input[@class='decorativeSubmit']",
     crmSfaLink:"text=CRM/SFA",
     leadsLink:"//a[text()='Leads']",
     leads:{
          createLeadLink:"//a[text()='Create Leads']",
           },

     accountsLink:""


   }

   async navigate(){
    await this.page.goto(URLConstants.baseUrl)
   }

   async enterCredentials(username:string,password:string){
    await this.page.fill(this.selectors.usernameField,username)
    await this.page.fill(this.selectors.pwdField,password)
   }
   async doLogin(){
           await this.page.click(this.selectors.loginButton)
   }

   async verifyUrl(){
    console.log(this.page.url())
   }

}