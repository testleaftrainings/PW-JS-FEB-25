import { HomePage } from "./HomePage";

export class LeadsPage extends HomePage{

    async clickCreateLead(){
        await this.page.click(this.selectors.leads.createLeadLink)
    }
    async clickfindLeads(){
        await this.page.click(this.selectors.leads.createLeadLink)
    }
    async clickMergeLeads(){
        await this.page.click(this.selectors.leads.createLeadLink)
    }

}