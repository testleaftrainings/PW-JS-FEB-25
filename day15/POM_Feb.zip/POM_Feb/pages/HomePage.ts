import { WelcomePage } from "./WelcomePage";

export class HomePage extends WelcomePage{


    async clickLeads(){
        await this.page.click(this.selectors.leadsLink)
    }
      
    async clickAccounts(){
        await this.page.click(this.selectors.accountsLink)
    }

}