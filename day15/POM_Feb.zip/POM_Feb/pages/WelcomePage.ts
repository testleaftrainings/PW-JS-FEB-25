import { LoginPage } from "./LoginPage";
import { URLConstants } from "../data/urlconstants";

export class WelcomePage extends LoginPage{
//     page:Page 
//     context:BrowserContext

//    constructor(context:BrowserContext,page:Page){
//     super(context,page)
//     this.page=page
//     this.context=context
//     this.homePageUrl()
//    }

//    async homePageUrl(){
//     await this.page.goto(URLConstants.homePageUrl)
//    }


// public selectors={
//     ...this.selectors,
//     contactLink: "//a[text()='Contacts']"   

    
//  }

    async clickCRM(){
        await this.page.click(this.selectors.crmSfaLink)
    }

}